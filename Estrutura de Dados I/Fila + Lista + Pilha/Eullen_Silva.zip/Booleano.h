/* define o tipo booleano */
#ifndef _Booleano_h
        #define _Booleano_h
        typedef enum{FALSE,TRUE} bool;
#endif

